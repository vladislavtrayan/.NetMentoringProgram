﻿namespace Task2
{
    public interface INumberParser
    {
        int Parse(string stringValue);
    }
}