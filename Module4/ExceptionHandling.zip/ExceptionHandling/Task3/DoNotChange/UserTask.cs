﻿namespace Task3.DoNotChange
{
    public class UserTask
    {
        public UserTask(string description)
        {
            Description = description;
        }

        public string Description { get; }
    }
}