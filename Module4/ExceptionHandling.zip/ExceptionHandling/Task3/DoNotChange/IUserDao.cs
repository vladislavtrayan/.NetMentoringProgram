﻿namespace Task3.DoNotChange
{
    public interface IUserDao
    {
        IUser GetUser(int id);
    }
}