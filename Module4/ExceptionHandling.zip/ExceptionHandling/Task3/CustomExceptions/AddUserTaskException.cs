﻿using System;

namespace Task3.CustomExceptions
{
    public class AddUserTaskException : Exception
    {
        
    }
}