﻿namespace Services
{
    public static class Delegates
    {
        public delegate void ItemFoundHandler(object sender, ItemFoundArgs e);
    }
}