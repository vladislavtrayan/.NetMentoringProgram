﻿using System;

namespace Task1.DoNotChange
{
	public class Order
	{
		public int OrderID { get; set; }
		public DateTime OrderDate { get; set; }
		public decimal Total { get; set; }
	}
}
